import { auth, db } from './firebase-config.js';
import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import { collection, doc, getDoc, getDocs, onSnapshot, query, setDoc, where, writeBatch, addDoc, updateDoc, serverTimestamp, orderBy } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';

const teamSeed = [
  {nome:'ALEXANDRE MODESTO DE OLIVEIRA',matricula:'005576',funcao:'OPERADOR USINA ESP',categoria:'Especialista',status:'Ativo'},
  {nome:'ALVARO SOUZA DA SILVA',matricula:'005313',funcao:'OPERADOR USINA PL',categoria:'Operador Pleno',status:'Ativo'},
  {nome:'DAVID FERNANDES DA SILVA',matricula:'710693',funcao:'OPERADOR USINA JR',categoria:'Operador Júnior',status:'Ativo'},
  {nome:'FRANCISCO HELTON MENDES VASCONCELOS',matricula:'004349',funcao:'OPERADOR USINA SR',categoria:'Operador Sênior',status:'Ativo'},
  {nome:'IZAQUIEL SILVA MAGALHAES',matricula:'709285',funcao:'OPERADOR USINA JR',categoria:'Operador Júnior',status:'Ativo'},
  {nome:'JARDIEL LOPES RODRIGUES',matricula:'006319',funcao:'OPERADOR USINA PL',categoria:'Operador Pleno',status:'Ativo'},
  {nome:'RAIMUNDO SOARES RAMOS NETO',matricula:'005413',funcao:'OPERADOR USINA SR',categoria:'Operador Sênior',status:'Ativo'}
];

const state = { user:null, profile:null, team:[], selectedOperator:null, requests:[], unsubscribeTeam:null, unsubscribeRequests:null };
const $ = id => document.getElementById(id);
const views = [...document.querySelectorAll('.view')];
const navItems = [...document.querySelectorAll('.nav-item')];

function toast(message){ const el=$('toast'); el.textContent=message; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2800); }
function initials(name='Usuário'){ return name.split(/\s+/).filter(Boolean).slice(0,2).map(p=>p[0]).join('').toUpperCase(); }
function normalizeRole(role='operador'){ const r=role.toLowerCase(); return ['supervisor','especialista','operador'].includes(r)?r:'operador'; }
function roleLabel(role){ return ({supervisor:'Supervisor',especialista:'Especialista',operador:'Operadores'})[role]||'Operadores'; }
function isLeadership(){ return ['supervisor','especialista'].includes(state.profile?.perfil); }
function formatAuthError(code){ const map={'auth/invalid-credential':'E-mail ou senha inválidos.','auth/invalid-email':'Informe um e-mail válido.','auth/too-many-requests':'Muitas tentativas. Aguarde alguns minutos.','auth/network-request-failed':'Falha de conexão. Verifique a internet.'}; return map[code]||'Não foi possível entrar. Confira os dados e tente novamente.'; }
function formatDate(value){ if(!value) return '-'; return new Date(`${value}T00:00:00`).toLocaleDateString('pt-BR'); }

async function login(){
  const email=$('email').value.trim(), password=$('password').value;
  if(!email||!password){$('loginMessage').textContent='Preencha o e-mail e a senha.';return;}
  $('loginButton').disabled=true;$('loginButton').textContent='Entrando...';$('loginMessage').textContent='';
  try{ await signInWithEmailAndPassword(auth,email,password); } catch(err){ $('loginMessage').textContent=formatAuthError(err.code); }
  finally{$('loginButton').disabled=false;$('loginButton').textContent='Acessar portal';}
}

async function getProfile(user){
  const snap=await getDoc(doc(db,'usuarios',user.uid));
  if(!snap.exists()) return {nome:user.email.split('@')[0],email:user.email,perfil:'operador',compartilhado:true,pendenteConfiguracao:true};
  return {...snap.data(),perfil:normalizeRole(snap.data().perfil)};
}

function applyProfile(){
  const p=state.profile, baseName=p.nome||state.user.email;
  const displayName=state.selectedOperator?.nome||baseName;
  $('userName').textContent=displayName;$('userRole').textContent=roleLabel(p.perfil);$('userInitials').textContent=initials(displayName);
  $('sidebarUser').innerHTML=`<strong>${displayName}</strong><span>${roleLabel(p.perfil)}</span>${p.perfil==='operador'?'<button id="switchOperatorButton" class="operator-switch" type="button">Trocar identificação</button>':''}`;
  document.querySelectorAll('.supervisor-only').forEach(el=>el.classList.toggle('hidden',p.perfil!=='supervisor'));
  $('welcomeTitle').textContent=`Olá, ${displayName.split(' ')[0]}`;
  if($('switchOperatorButton')) $('switchOperatorButton').addEventListener('click',openOperatorChooser);
  updateRequestPanel();
}

function showApp(){ $('loading').classList.add('hidden');$('loginPage').classList.add('hidden');$('app').classList.remove('hidden');$('connectionBadge').textContent='Online';applyProfile();listenTeam();listenRequests();loadDashboardCounts(); }
function showLogin(){ $('loading').classList.add('hidden');$('app').classList.add('hidden');$('loginPage').classList.remove('hidden'); if(state.unsubscribeTeam)state.unsubscribeTeam();if(state.unsubscribeRequests)state.unsubscribeRequests(); }
function openView(id){ views.forEach(v=>v.classList.toggle('active',v.id===id));navItems.forEach(n=>n.classList.toggle('active',n.dataset.view===id)); const titles={dashboard:['Dashboard','Visão geral da Equipe E'],equipe:['Equipe','Cadastro e composição da equipe'],folgas:['Folgas','Solicitações e aprovações'],banco:['Banco de horas','Saldos e importações do RH'],ferias:['Férias','Planejamento anual'],treinamentos:['Treinamentos','Capacitações e certificações']}; $('pageTitle').textContent=titles[id][0];$('pageSubtitle').textContent=titles[id][1];$('sidebar').classList.remove('open');window.scrollTo({top:0,behavior:'smooth'}); }

function renderTeam(filter=''){
  const term=filter.trim().toLowerCase();
  const list=state.team.filter(p=>[p.nome,p.matricula,p.funcao,p.categoria].some(v=>String(v||'').toLowerCase().includes(term)));
  $('teamTableBody').innerHTML=list.map(p=>`<tr><td><div class="person-cell"><span class="person-avatar">${initials(p.nome)}</span><strong>${p.nome}</strong></div></td><td>${p.matricula||'-'}</td><td>${p.funcao||'-'}</td><td><span class="role-pill">${p.categoria||'-'}</span></td><td><span class="active-pill">${p.status||'Ativo'}</span></td></tr>`).join('')||'<tr><td colspan="5">Nenhum colaborador encontrado.</td></tr>';
  $('teamCount').textContent=`${list.length} registro${list.length===1?'':'s'}`;$('metricEquipe').textContent=state.team.length;renderCategories();populateOperatorSelect();
}
function renderCategories(){ const counts=state.team.reduce((acc,p)=>{acc[p.categoria]=(acc[p.categoria]||0)+1;return acc;},{}),max=Math.max(1,...Object.values(counts)); $('categoryList').innerHTML=Object.entries(counts).map(([name,count])=>`<div class="category-row"><span>${name}</span><div class="category-track"><span style="width:${count/max*100}%"></span></div><strong>${count}</strong></div>`).join('')||'<p class="muted">Cadastre a equipe para visualizar a distribuição.</p>'; }
function listenTeam(){ if(state.unsubscribeTeam)state.unsubscribeTeam();state.unsubscribeTeam=onSnapshot(collection(db,'colaboradores'),snap=>{state.team=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>a.nome.localeCompare(b.nome));renderTeam($('teamSearch').value);if(state.profile?.perfil==='operador'&&!state.selectedOperator)openOperatorChooser();},err=>{console.error(err);$('connectionBadge').textContent='Sem acesso ao banco';toast('Não foi possível consultar a equipe. Verifique as regras do Firestore.');}); }
async function seedTeam(){ if(state.profile.perfil!=='supervisor')return;if(!confirm('Cadastrar os 7 colaboradores iniciais no Firestore?'))return;const batch=writeBatch(db);teamSeed.forEach(p=>batch.set(doc(db,'colaboradores',p.matricula),p,{merge:true}));await batch.commit();toast('Equipe inicial cadastrada com sucesso.'); }

function populateOperatorSelect(){ if(!$('operatorSelect'))return;const current=$('operatorSelect').value;$('operatorSelect').innerHTML=state.team.filter(p=>p.categoria!=='Especialista').map(p=>`<option value="${p.id}">${p.nome}</option>`).join('');if(current)$('operatorSelect').value=current; }
function openOperatorChooser(){ if(state.profile?.perfil!=='operador')return;$('operatorIdentityConfirm').checked=false;$('operatorChooserMessage').textContent='';populateOperatorSelect();$('operatorChooser').classList.remove('hidden'); }
function confirmOperator(){ const id=$('operatorSelect').value, person=state.team.find(p=>p.id===id);if(!person){$('operatorChooserMessage').textContent='Selecione um colaborador.';return;}if(!$('operatorIdentityConfirm').checked){$('operatorChooserMessage').textContent='Confirme sua identificação para continuar.';return;}state.selectedOperator=person;sessionStorage.setItem('equipeESelectedOperator',JSON.stringify(person));$('operatorChooser').classList.add('hidden');applyProfile();renderRequests();toast(`Identificação confirmada: ${person.nome}`); }

function updateRequestPanel(){
  if(!$('requestPanel'))return;
  const operator=state.selectedOperator;
  const leadership=isLeadership();
  $('requestPanel').classList.toggle('hidden',leadership);
  $('selectedOperatorBadge').classList.toggle('hidden',!operator);
  if(operator){$('selectedOperatorBadge').textContent=`Identificado: ${operator.nome}`;$('requestOperatorName').value=operator.nome;}
  $('requestListTitle').textContent=leadership?'Solicitações da equipe':'Minhas solicitações';
  $('requestListSubtitle').textContent=leadership?'Analise e atualize o status das solicitações.':'Histórico do colaborador selecionado.';
}

function listenRequests(){ if(state.unsubscribeRequests)state.unsubscribeRequests();state.unsubscribeRequests=onSnapshot(collection(db,'solicitacoes_folga'),snap=>{state.requests=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.criadoEm?.seconds||0)-(a.criadoEm?.seconds||0));renderRequests();$('metricFolgas').textContent=state.requests.filter(r=>r.status==='Pendente').length;},err=>{console.error(err);toast('Não foi possível carregar as solicitações.');}); }
function visibleRequests(){ if(isLeadership())return state.requests;if(!state.selectedOperator)return[];return state.requests.filter(r=>r.colaboradorId===state.selectedOperator.id); }
function renderRequests(){ if(!$('requestCards'))return;const list=visibleRequests();$('requestCards').innerHTML=list.map(r=>`<article class="request-card ${String(r.status||'').toLowerCase()}"><header><div><h4>${r.colaboradorNome}</h4><p>${formatDate(r.dataInicial)} a ${formatDate(r.dataFinal)} • ${r.tipo}</p></div><span class="status-badge neutral">${r.status||'Pendente'}</span></header><p><strong>Justificativa:</strong> ${r.justificativa||'-'}</p>${r.analisadoPorNome?`<p><strong>Analisado por:</strong> ${r.analisadoPorNome}</p>`:''}${isLeadership()&&r.status==='Pendente'?`<div class="request-actions"><button class="approve-button" data-action="approve" data-id="${r.id}">Aprovar</button><button class="reject-button" data-action="reject" data-id="${r.id}">Reprovar</button></div>`:''}</article>`).join('')||'<p class="muted">Nenhuma solicitação encontrada.</p>';
  $('requestCards').querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>reviewRequest(btn.dataset.id,btn.dataset.action==='approve'?'Aprovada':'Reprovada')));
}
async function submitRequest(){
  const op=state.selectedOperator;if(!op){openOperatorChooser();return;}
  const start=$('requestStart').value,end=$('requestEnd').value||start,reason=$('requestReason').value.trim();
  if(!start){$('requestMessage').textContent='Informe a data da folga.';return;}if(!$('requestConfirmIdentity').checked){$('requestMessage').textContent='Confirme sua identificação.';return;}
  if(!confirm(`Confirma a solicitação em nome de ${op.nome}?`))return;
  $('submitRequestButton').disabled=true;$('requestMessage').textContent='';
  try{await addDoc(collection(db,'solicitacoes_folga'),{solicitanteUid:state.user.uid,colaboradorId:op.id,colaboradorNome:op.nome,matricula:op.matricula,tipo:$('requestType').value,dataInicial:start,dataFinal:end,justificativa:reason,status:'Pendente',criadoEm:serverTimestamp()});$('requestStart').value='';$('requestEnd').value='';$('requestReason').value='';$('requestConfirmIdentity').checked=false;toast('Solicitação enviada para análise.');}
  catch(err){console.error(err);$('requestMessage').textContent='Não foi possível enviar. Verifique as regras do Firestore.';}
  finally{$('submitRequestButton').disabled=false;}
}
async function reviewRequest(id,status){ if(!isLeadership())return;const reason=status==='Reprovada'?(prompt('Informe o motivo da reprovação:')||''):'';await updateDoc(doc(db,'solicitacoes_folga',id),{status,observacaoAnalise:reason,analisadoPorUid:state.user.uid,analisadoPorNome:state.profile.nome||state.user.email,analisadoEm:serverTimestamp()});toast(`Solicitação ${status.toLowerCase()}.`); }
async function loadDashboardCounts(){ try{const pend=await getDocs(query(collection(db,'solicitacoes_folga'),where('status','==','Pendente')));$('metricFolgas').textContent=pend.size;}catch{$('metricFolgas').textContent='0';} }
function setDate(){const now=new Date();$('todayDay').textContent=now.getDate();$('todayMonth').textContent=now.toLocaleDateString('pt-BR',{month:'short'}).replace('.','');}

$('loginButton').addEventListener('click',login);$('password').addEventListener('keydown',e=>{if(e.key==='Enter')login();});$('togglePassword').addEventListener('click',()=>{$('password').type=$('password').type==='password'?'text':'password';});$('logoutButton').addEventListener('click',()=>signOut(auth));$('menuButton').addEventListener('click',()=>$('sidebar').classList.toggle('open'));navItems.forEach(item=>item.addEventListener('click',()=>openView(item.dataset.view)));document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>openView(b.dataset.go)));$('teamSearch').addEventListener('input',e=>renderTeam(e.target.value));$('seedTeamButton').addEventListener('click',()=>seedTeam().catch(e=>{console.error(e);toast('Falha ao cadastrar equipe. Verifique as permissões.');}));$('confirmOperatorButton').addEventListener('click',confirmOperator);$('submitRequestButton').addEventListener('click',submitRequest);

setDate();
onAuthStateChanged(auth,async user=>{
  state.user=user;
  if(!user){state.profile=null;state.selectedOperator=null;sessionStorage.removeItem('equipeESelectedOperator');showLogin();return;}
  try{state.profile=await getProfile(user);if(state.profile.perfil==='operador'){const saved=sessionStorage.getItem('equipeESelectedOperator');if(saved)try{state.selectedOperator=JSON.parse(saved);}catch{}}showApp();}catch(err){console.error(err);await signOut(auth);$('loginMessage').textContent='Não foi possível carregar seu perfil. Verifique o Firestore.';showLogin();}
});
