# Portal Gestão Equipe E — v1.1

Piloto com três acessos:

- Supervisor: conta exclusiva e acesso completo.
- Especialista: conta exclusiva de Alexandre, com aprovação de folgas.
- Operadores: uma conta compartilhada; cada operador seleciona e confirma o próprio nome após o login.

## Funcionalidades desta versão

- Firebase Authentication por e-mail e senha.
- Perfis por documento na coleção `usuarios`.
- Cadastro inicial dos sete colaboradores.
- Solicitação de folga pelo operador identificado.
- Aprovação ou reprovação por Supervisor e Especialista.
- Histórico compartilhado no Firestore.
- Layout responsivo para celular e computador.

Consulte `CONFIGURACAO_PASSO_A_PASSO.txt`.
